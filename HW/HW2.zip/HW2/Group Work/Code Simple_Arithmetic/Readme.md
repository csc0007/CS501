# Homework 2 Question 5
# Question Name
Simple Arithmetic
# Copyright
Sicheng Chen, Siyi Du
# Vedio Demo
https://drive.google.com/file/d/10vN0AbthsMduvLkEPpMw3GVSmNIWOKwd/view?usp=drive_link
