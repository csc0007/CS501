# Homework 2 Question 6
# Question Name
Calculator
# Copyright
Sicheng Chen, Siyi Du
# Vedio Demo
https://drive.google.com/file/d/1HM3x93inMhx5GD7sYF1dOZCITDwatPk0/view?usp=drive_link
